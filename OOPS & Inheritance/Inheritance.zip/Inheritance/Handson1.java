package Inheritance;


class Animal
{
public void eat()
{
System.out.println("Animals Eat");	
}
public void sleep()
{
	System.out.println("Animals Sleep");
}
}
class Bird extends Animal{
	@Override
	public void sleep() {
		System.out.println("Birds Sleep");
	}
	@Override
	public void eat()
	{
		System.out.println("Birds Eat");
	}
	public void fly()
	{
		System.out.println("Birds fly");
	}
	
}
public class Handson1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal=new Animal();
		Bird bird=new Bird();
		animal.eat();animal.sleep();
		bird.eat();bird.sleep();bird.fly();
	}

}
