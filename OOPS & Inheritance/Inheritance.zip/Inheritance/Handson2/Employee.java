package Handson2;

public class Employee extends Person {
	
	double salary;
	int yearofEmployement;
	String nationalInsurance;
	public Employee(String name, double salary, int yearofEmployement, String nationalInsurance) {
		super(name);
		this.salary = salary;
		this.yearofEmployement = yearofEmployement;
		this.nationalInsurance = nationalInsurance;
	}
	@Override
	public String toString() {
		return "Employee [name= " + name + ",salary=" + salary + ", yearofEmployement=" + yearofEmployement + ", nationalInsurance="
				+ nationalInsurance + "]";
	}
	
	
	
}
