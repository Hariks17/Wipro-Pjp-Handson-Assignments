package Handson2;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee=new Employee("Hari",200,2020,"aej123");
		System.out.println(employee);
	}

}
