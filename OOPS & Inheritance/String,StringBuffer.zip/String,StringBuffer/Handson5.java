package StringandStringBuffer;

import java.util.Scanner;

public class Handson5 {
	public static void main(String args[])
	{
	String word=new Scanner(System.in).next();
	
	System.out.println(word.substring(1,word.length()-1));
	}
	
}
