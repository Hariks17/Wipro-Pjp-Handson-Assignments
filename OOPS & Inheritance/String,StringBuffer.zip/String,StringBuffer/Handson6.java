package StringandStringBuffer;

import java.util.Scanner;

public class Handson6 {
	public static void main(String args[])
	{
	String a=new Scanner(System.in).next();
	String b=new Scanner(System.in).next();
	String shortString= a.length()>b.length()?b:a;
	String longString=a.length()>b.length()?a:b;
	System.out.println(shortString+longString+shortString);
	
	
	
	}
	
}
