package StringandStringBuffer;

import java.util.Scanner;

public class Handson10 {
	public static void main(String args[])
	{
	String a=new Scanner(System.in).next();
	int n=new Scanner(System.in).nextInt();
	String newString="";
	for(int i=0;i<n;i++)
		newString+=a.substring(a.length()-3);
	
	System.out.println(newString);
	}

	
	
}
