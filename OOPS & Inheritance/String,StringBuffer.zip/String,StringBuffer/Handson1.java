package StringandStringBuffer;

import java.util.Scanner;

public class Handson1 {
	public static void main(String args[])
	{
		String word=new Scanner(System.in).next();
		if(word.equals(new StringBuffer(word).reverse().toString()))
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not a palindrome");
		}
	}
}
