package StringandStringBuffer;

import java.util.Scanner;

public class Handson8 {
	public static void main(String args[])
	{
		//ab*cd 
	String a=new Scanner(System.in).next();
	StringBuffer str=new StringBuffer(a);
	int i=a.indexOf("*");
	str.delete(i-1,i+2);
	System.out.println(str);
	}
	
}
