package StringandStringBuffer;

import java.util.Scanner;

public class Handson2 {
	public static void main(String args[])
	{
	String word=new Scanner(System.in).next().toLowerCase();
	String str[]=word.split(",");

	if(str[0].charAt(str[0].length()-1)==str[1].charAt(0))
	{
		String s=str[0].substring(0,str[0].length()-1)+str[1];
		System.out.println(s);
	}
	else
	{
		System.out.println(str[0]+" "+str[1]);
	}
	}
}
