package StringandStringBuffer;

import java.util.Scanner;

public class Handson9 {
	public static void main(String args[])
	{
		//ab*cd 
	String a=new Scanner(System.in).next();
	String b=new Scanner(System.in).next();
	int al=a.length();int bl=b.length();
	StringBuffer str=new StringBuffer("");
	int s=al>bl?bl:al;
	
	if(a.length()==b.length())
	{
		for(int i=0;i<a.length();i++)
		{
		str.append(a.charAt(i));
		str.append(b.charAt(i));
		}
	}
	else {
	if(s==al)
	{
		for(int i=0;i<al;i++)
		{
			str.append(a.charAt(i));
			str.append(b.charAt(i));
		}
		str.append(b.substring(al,bl));
	}
	else
	{
		for(int i=0;i<bl;i++)
		{
			str.append(a.charAt(i));
			str.append(b.charAt(i));
		}
		str.append(a.substring(bl,al));
	}}
	
	System.out.println(str);
	}

	
	
}
