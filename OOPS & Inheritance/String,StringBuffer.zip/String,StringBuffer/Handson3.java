package StringandStringBuffer;

import java.util.Scanner;

public class Handson3 {
	public static void main(String args[])
	{
	String word=new Scanner(System.in).next();
	String twoletters=word.substring(0,2);
	String answer="";
	for(int i=0;i<word.length();i++)
		answer+=twoletters;
	
	System.out.println(answer);
	
	}
	
}
