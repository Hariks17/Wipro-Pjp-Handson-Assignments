package StringandStringBuffer;

import java.util.Scanner;

public class Handson7 {
	public static void main(String args[])
	{
	String a=new Scanner(System.in).next();
	if(a.charAt(0)=='x'&&a.charAt(a.length()-1)=='x')
	System.out.println(a.substring(1,a.length()-1));
	else
	System.out.println(a);
	
	}
	
}
