package StringandStringBuffer;

import java.util.Scanner;

public class Handson4 {
	public static void main(String args[])
	{
	String word=new Scanner(System.in).next();
	int l= word.length();
	if(l%2==0)
	{
		System.out.println(word.substring(0,l/2));
	}
	else
	System.out.println("null");
	}
	
}
