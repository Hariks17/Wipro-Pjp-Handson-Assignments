package Classes_and_Objects;

class Box{
	int length;
	int height;
	int depth;
	
	public Box(int length, int height, int depth) {
		
		this.length = length;
		this.height = height;
		this.depth = depth;
	}
	public int volume()
	{
		return length*depth*height;
	}
	
}

public class Handson1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box b=new Box(5,6,7);
		System.out.println(b.volume());
		
	}

}
