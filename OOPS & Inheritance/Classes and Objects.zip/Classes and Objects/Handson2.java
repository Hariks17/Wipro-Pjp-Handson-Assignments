package Classes_and_Objects;

class Calculator{	
	
	
	
	 public static int powerInt(int num1,int num2)
	{
		return (int)Math.pow(num1, num2);
		
	}
	 public static double powerDouble(double num1,double num2)
	 {
		return Math.pow(num1,num2);
		 
	 }
	
}

public class Handson2 {

	public static void main(String[] args) {

		int powerIntValue=Calculator.powerInt(2, 5);
		double powerDoubleValue=Calculator.powerDouble(2, 5);
		
		System.out.println(powerIntValue);
		System.out.println(powerDoubleValue);
		
	}

}
