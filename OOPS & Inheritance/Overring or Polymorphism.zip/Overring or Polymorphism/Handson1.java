package Overriding_Polymorphism;


class Fruit{
	String name;
	String taste;
	int size;
	public void eat()
	{
		name="Name of the Fruit";
		taste="Taste of the Fruit";
	}
}
class Apple extends Fruit{
	@Override
	public void eat() {
		name="Apple";
		taste="Sweet";
		System.out.println("Name : "+name+" and Taste : "+taste);
	}
}
class Orange extends Fruit{
	@Override
	public void eat() {
		name="Orange";
		taste="Bitter and Sweet";
		System.out.println("Name : "+name+" and Taste : "+taste);
	}
}

public class Handson1 {

	public static void main(String args[])
	{
		Orange orange =new Orange();
		Apple apple =new Apple();
		apple.eat();
		orange.eat();
	}

}
